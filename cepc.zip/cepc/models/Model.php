<?php include 'Connection.php'?>
<?php
/*
|---------------------------------------------------------------|
|																|
|	Seguido del guion bajo, colocar nombre del metodo			|
|																|
|---------------------------------------------------------------|
*/
	global $model;
	
	class Model
	{ 
		private $id;
		private $query;		
		private $result;	
		private $user;
		private $password;
		private $clave;
		
		public function insert_/*name*/($data){
			
			$connection = new Connection;
			
			$connection->close();
		}
		
		public function select_courses($data){
			
			$connection = new Connection;
			
			$this->query = "SELECT * FROM cursos";
			$this->result = mysqli_query($connection->open(), $this->query);
			
			return $this->result;
			
			$connection->close();
		}
		
		public function select_users($data){
			
			$connection = new Connection;
			
			$this->query = "SELECT * FROM usuarios";
			$this->result = mysqli_query($connection->open(), $this->query);
			
			return $this->result;
			
			$connection->close();
		}
		
		public function select_user($data){
			
			$connection = new Connection;
			
			$this->user = mysqli_real_escape_string($connection->open(), $data[0]);
			$this->password = md5(mysqli_real_escape_string($connection->open(), $data[1]));
			
			$this->query = "SELECT * FROM usuarios WHERE cedulaUsuario = '".$this->user."'
							AND passwordUsuario = '".$this->password."' LIMIT 1";
			
			$this->result = mysqli_query($connection->open(), $this->query);
			
			return $this->result;
			
			$connection->close();
		
		}
		
		public function update_/*name*/($data){
			
			$connection = new Connection;
			
			$connection->close();
		
		}
		
		public function delete_/*name*/($data){
			
			$connection = new Connection;
			
			$connection->close();
		}
		
		public function show_user($data){
		
			$connection = new Connection;
			
			$this->id = mysqli_real_escape_string($connection->open(), $data);
			$this->query = "SELECT * FROM usuarios WHERE idUsuario = '".$this->id."' LIMIT 1";
			$this->result = mysqli_query($connection->open(), $this->query);
			
			return $this->result;
			
			$connection->close();
		}
		
		public function show_course($data){
			
			$connection = new Connection;
			
			$this->id = mysqli_real_escape_string($connection->open(), $data);
			$this->query = "SELECT * FROM cursos WHERE idCursos = '".$this->id."' LIMIT 1";
			$this->result = mysqli_query($connection->open(), $this->query);
			
			return $this->result;
			
			$connection->close();
			
		}
	
	}
	
	$model = new Model;