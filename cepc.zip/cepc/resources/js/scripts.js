$(document).ready(function(){
				
	$("#logout").click(function(event){
		
		$("#sign-out").submit();
		
		event.preventDefault();
		
	});
	
	$(".campo-numeros").keypress(function(event){
	
		var tecla = (document.all) ? event.keyCode : event.which;
		if (tecla==8) return true; //Tecla de retroceso (para poder borrar)
		if (tecla==48) return true;
		if (tecla==49) return true;
		if (tecla==50) return true;
		if (tecla==51) return true;
		if (tecla==52) return true;
		if (tecla==53) return true;
		if (tecla==54) return true;
		if (tecla==55) return true;
		if (tecla==56) return true;
		if (tecla==57) return true;
		var patron = /1/; //ver nota
		var te = String.fromCharCode(tecla);
		return patron.test(te);
		
	})
	
	$(".campo-letras").keypress(function(event){

		var key = event.keyCode || event.which;
		var tecla = String.fromCharCode(key).toLowerCase();
		var letras = " àèìòùáéíóúabcdefghijklmnñopqrstuvwxyzABCDEFGHIJQLMNÑOPQRSTUVWXYZÀÈÌÒÙÁÉÍÓÚ";
		var especiales = [8,37,39,46];
		var tecla_especial = false;
		
		for(var i in especiales){
			 
			 if(key == especiales[i]){
				  tecla_especial = true;
				  break;
			} 
		 
		 }
	 
		if(letras.indexOf(tecla)==-1 && !tecla_especial)
			
		return false;
		
		$(this).keyup(function(){
			
			texto=$(this).val();
			texto=texto.toUpperCase();
			$(this).val(texto);
		})
	
	});
	
	$(".campo").keyup(function(){
		
		texto=$(this).val();
		texto=texto.toUpperCase();
		$(this).val(texto);
		
		var aBu=$(this).attr("data-id");
		
		if(aBu=="con-dat"){
			
			var dat=$(this).val();
			
			$.ajax({
				
				type:'POST',
				url:'../procesar/consultar.php?id=datos',
				data:{'dat':dat},
			})
			.done(function(respuestaServidor){
				
				$(".mostrar").html(respuestaServidor);
				
			})
		
		}
		
		else if(aBu=="fil-dat"){
			
			_this=this;

			$.each($(".tab-1 tbody tr"),function(){
				
				if($(this).text().toLowerCase().indexOf($(_this).val().toLowerCase())===-1)
	
						
					$(this).hide();
				
				else
					
					$(this).show();
				
			})
			
		}
		
		
	});
	
})