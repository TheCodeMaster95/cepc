var view = {
	
	ajax: function(data, idResult, nodeEvent, dataType){
	
		if(dataType == 'json'){
	
			$.ajax({
				
				type:'POST',
				url:'ajax/controller.php',
				data:{'data': data, 'nodeEvent': nodeEvent, 'dataType': dataType},
				dataType:'JSON',
				beforeSend:function(){ 
					
					//Load Gif
				
				}
			
			})
			.done(function(response){
	
				for(i in response){
					
					$("#"+i+"").html(response[i]);
					
				}
		
			});
		
		}
		
		else if(dataType == 'string'){
			
			$.ajax({
				
				type:'POST',
				url:'ajax/controller.php',
				data:{'data': data, 'nodeEvent': nodeEvent, 'dataType': dataType},
				beforeSend:function(){ 
					
					//Load Gif
				
				}
			
			})
			.done(function(response){ 
				
				$("#"+idResult+"").html(response);
				
			});
			
		}
		
	},
	
}

var val = { data: null, idResult: null, nodeEvent: null, dataType: null }

