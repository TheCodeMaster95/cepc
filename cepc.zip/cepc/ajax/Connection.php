<?php
	
	global $connection;
	
	class Connection
	{
		private $hostname	=	'localhost';
		private $user		=	'root';
		private $password	=	'';
		private $database	=	'2969203_cepc';	
		private $result;
		
		public function open(){
			
			$this->result = mysqli_connect(
				
				$this->hostname,
				$this->user,
				$this->password,
				$this->database
			
			);
			
			return $this->result;
			
		}
		
		public function close(){
			
			$this->result =mysqli_close($this->open());
			
			return $this->result;
		}
		
	}
	
	$connection = new Connection;
	
	if($connection->open() == false){
		
		die('Error de conexion con el servidor'.' '.mysqli_connect_error());
		
		$connection->close();
	}