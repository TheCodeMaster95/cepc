<?php  include 'Connection.php'?>
<?php	
/*
|---------------------------------------------------------------|
|																|
|	Seguido del guion bajo, colocar el nombre del metodo		|
|																|
|---------------------------------------------------------------|
*/	
	global $model;
	
	class Model
	{ 	
		private $id;			private $apellido;
		private $query;			private $password;	
		private $result;		private $nombre;
		private $user;			private $costo;
		private $duracion;		private $cedula;
		private $descripcion;
		private $tipo;
		
		public function insert_course($data){
			
			$connection = new Connection;
			
			$this->nombre = mysqli_real_escape_string($connection->open(), $data[0]);
			$this->duracion = mysqli_real_escape_string($connection->open(), $data[1]);
			$this->costo = mysqli_real_escape_string($connection->open(), $data[2]);
			$this->descripcion = mysqli_real_escape_string($connection->open(), $data[3]);
			
			$this->query = "INSERT INTO cursos (nombreCursos, contenidoCursos, duracionCursos, precioUnidades, costoCursos, descripcionCursos)
							VALUES ('".$this->nombre."', 'null', '".$this->duracion."', 'null', '".$this->costo."', '".$this->descripcion."')";
			
			$this->result = mysqli_query($connection->open(), $this->query);
			
			return $this->result;
			
			$connection->close();
			
		}
		
		public function insert_user($data){
			
			$connection = new Connection;
			
			$this->cedula = mysqli_real_escape_string($connection->open(), $data[0]);
			$this->nombre = mysqli_real_escape_string($connection->open(), $data[1]);
			$this->apellido = mysqli_real_escape_string($connection->open(), $data[2]);
			$this->usuario = mysqli_real_escape_string($connection->open(), $data[3]);
			$this->password =  md5(mysqli_real_escape_string($connection->open(), $data[4]));
			
			//$this->password_encryp = password_hash($this->password, PASSWORD_DEFAULT);
			
			$this->query = "INSERT INTO usuarios (cedulaUsuario, nombreUsuario, apellidoUsuario, tipoUsuario, passwordUsuario)
							VALUES ('".$this->cedula."', '".$this->nombre."', '".$this->apellido."', '".$this->usuario."', '".$this->password."')";
			
			$this->result = mysqli_query($connection->open(), $this->query);
			
			return $this->result;
			
			$connection->close();
			
		}
		
		public function select_course($data){
			
			$connection = new Connection;
			
			$this->nombre = mysqli_real_escape_string($connection->open(), $data[0]);
			$this->query = "SELECT * FROM cursos WHERE nombreCursos = '".$this->nombre."'";
			$this->result = mysqli_query($connection->open(), $this->query);
			
			return $this->result;
			
			$connection->close();
		
		}
		
		public function select_user($data){
			
			$connection = new Connection;
			
			$this->cedula = mysqli_real_escape_string($connection->open(), $data[0]);
			$this->query = "SELECT * FROM usuarios WHERE cedulaUsuario = '".$this->cedula."'";
			$this->result = mysqli_query($connection->open(), $this->query);
			
			return $this->result;
			
			$connection->close();
		
		}
		
		public function update_profile($data){
			
			$connection = new Connection;
			
			$this->nombre = mysqli_real_escape_string($connection->open(), $data[0]);
			$this->apellido = mysqli_real_escape_string($connection->open(), $data[1]);
			$this->password = mysqli_real_escape_string($connection->open(), $data[2]);
			$this->id = mysqli_real_escape_string($connection->open(), $data[3]);
			
			$this->query = "UPDATE usuarios SET nombreUsuario = '".$this->nombre."', apellidoUsuario = '".$this->apellido."',
							passwordUsuario = '".$this->password."' WHERE idUsuario = '".$this->id."'";
			
			$this->result = mysqli_query($connection->open(), $this->query);
			
			return $this->result;
			
			$connection->close();
		
		}
		
		public function update_user($data){
			
			$connection = new Connection;
			
			$this->tipo = mysqli_real_escape_string($connection->open(), $data[0]);
			$this->id = mysqli_real_escape_string($connection->open(), $data[1]);
			
			$this->query = "UPDATE usuarios SET tipoUsuario = '".$this->tipo."' WHERE idUsuario = '".$this->id."'";
			
			$this->result = mysqli_query($connection->open(), $this->query);
			
			return $this->result;
			
			$connection->close();
		
		}
		
		public function update_course($data){
			
			$connection = new Connection;
			
			$this->nombre = mysqli_real_escape_string($connection->open(), $data[0]);
			$this->duracion = mysqli_real_escape_string($connection->open(), $data[1]);
			$this->costo = mysqli_real_escape_string($connection->open(), $data[2]);
			$this->descripcion = mysqli_real_escape_string($connection->open(), $data[3]);
			$this->id = mysqli_real_escape_string($connection->open(), $data[4]);
			
			$this->query = "UPDATE cursos SET nombreCursos = '".$this->nombre."', duracionCursos = '".$this->duracion."',
							costoCursos = '".$this->costo."', descripcionCursos = '".$this->descripcion."' WHERE idCursos = '".$this->id."'";
			
			$this->result = mysqli_query($connection->open(), $this->query);
			
			return $this->result;
			
			$connection->close();
		
		}
		
		public function delete_course($data){
			
			$connection = new Connection;
			
			for($i = 0; $i < count($data); $i++){
				
				$this->id = mysqli_real_escape_string($connection->open(), $data[$i]);
				$this->query = "DELETE FROM cursos WHERE idCursos = '".$this->id."'";
				$this->result = mysqli_query($connection->open(), $this->query);
			
			}
			
			return $this->result;
			
			$connection->close();
		
		}
		
		public function delete_user($data){
			
			$connection = new Connection;
			
			for($i = 0; $i < count($data); $i++){
				
				$this->id = mysqli_real_escape_string($connection->open(), $data[$i]);
				$this->query = "DELETE FROM usuarios WHERE idUsuario = '".$this->id."'";
				$this->result = mysqli_query($connection->open(), $this->query);
			
			}
			
			return $this->result;
			
			$connection->close();
		
		}
		
		public function show_/*name*/($data){
			
			$connection = new Connection;
			
			$connection->close();
		
		}
		
	}
	
	$model = new Model;