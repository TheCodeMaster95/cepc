<?php include 'Model.php'; ?>
<?php

$data     		= 		$_POST["data"];
$nodeEvent    	= 		$_POST["nodeEvent"];
$dataType 		= 		$_POST["dataType"];

$result = null; //Para almacenar los datos del modelo

if($dataType == 'json'){
	
	$idResult = new stdClass; //Para almacenar el objeto de respuesta
	
	/*
	if($nodeEvent == 'val.nodeEvent'){
		
		$result = $model->method_name($data);
	
		$idResult->val.idResult = $result['index'];
			
		echo json_encode($idResult);
		
	}
	*/

}          
if($dataType == 'string'){
	
	$idResult = null; //Para almacenar el string de respuesta
	
	if($nodeEvent == 'editar-perfil'){
		
		$result = $model->update_profile($data);
		
		if($result == true){
			
			$idResult = '<script>
							alert("Perfil editado exitosamente!");
							document.location.href="?url=perfil";
						 </script>';
						 
			echo $idResult;
			
		}
		else{
			
			$idResult = '<script>
							alert("Error al editar perfil!");
							document.location.href="?url=perfil";
						</script>';
			
			echo $idResult;
		}
		
	}
	
	if($nodeEvent == 'eliminar-curso'){
		
		$result = $model->delete_course($data);
		
		if($result == true){
			
			$idResult =	'<script>
							alert("Curso(s) eliminado(s) exitosamente!");
							document.location.href="?url=cursos";
						 </script>';
						 
			echo $idResult;
		
		}
		else{
			
			$idResult =	'<script>
							alert("Error al eliminar curso(s)!");
							document.location.href="?url=cursos";
						 </script>';
						 
			echo $idResult;
			
		}
		
	}
	
	if($nodeEvent == 'eliminar-usuario'){
		
		$result = $model->delete_user($data);
		
		if($result == true){
			
			$idResult =	'<script>
							alert("Usuario(s) eliminado(s) exitosamente!");
							document.location.href="?url=usuarios";
						 </script>';
						 
			echo $idResult;
		
		}
		else{
			
			$idResult =	'<script>
							alert("Error al eliminar usuario(s)!");
							document.location.href="?url=usuarios";
						 </script>';
						 
			echo $idResult;
			
		}
		
	}
	
	if($nodeEvent == 'registrar-curso'){
		
		$result = $model->select_course($data);
		
		if(mysqli_num_rows($result) > 0){
			
			$idResult = '<script>
							alert("El curso ya se encuentra registrado!");
						 </script>';
			
			echo $idResult;
			
		}
		else{
		
			$result = $model->insert_course($data);
			
			if($result == true){
				
				$idResult = '<script>
								alert("Curso registrado exitosamente!");
								document.location.href="?url=cursos";
							 </script>';
							 
				echo $idResult;
			
			}
			else{
				
				$idResult =	'<script>
								alert("Error al registrar curso!");
								document.location.href="?url=cursos";
							 </script>';
							 
				echo $idResult;
				
			}
			
		}
		
	}
	
	if($nodeEvent == 'registrar-usuario'){
		
		$result = $model->select_user($data);
		
		if(mysqli_num_rows($result) > 0){
			
			$idResult = '<script>
							alert("La cedula ya se encuentra registrada!");
						 </script>';
			
			echo $idResult;
			
		}
		else{
		
			$result = $model->insert_user($data);
			
			if($result == true){
				
				$idResult = '<script>
								alert("Usuario registrado exitosamente!");
								document.location.href="?url=usuarios";
							 </script>';
							 
				echo $idResult;
			
			}
			else{
				
				$idResult =	'<script>
								alert("Error al registrar usuario!");
								document.location.href="?url=usuarios";
							 </script>';
							 
				echo $idResult;
				
			}
			
		}
		
	}
	
	if($nodeEvent == 'editar-curso'){
		
		$result = $model->update_course($data);
			
		if($result == true){
			
			$idResult = '<script>
							alert("Curso editado exitosamente!");
							document.location.href="?url=cursos";
						 </script>';
						 
			echo $idResult;
		
		}
		
		else{
			
			$idResult =	'<script>
							alert("Error al editar curso!");
							document.location.href="?url=cursos";
						 </script>';
						 
			echo $idResult;
			
		}
		
	}
	
	if($nodeEvent == 'editar-usuario'){
		
		$result = $model->update_user($data);
			
		if($result == true){
			
			$idResult = '<script>
							alert("Usuario editado exitosamente!");
							document.location.href="?url=usuarios";
						 </script>';
						 
			echo $idResult;
		
		}
		
		else{
			
			$idResult =	'<script>
							alert("Error al editar usuario!");
							document.location.href="?url=usuarios";
						 </script>';
						 
			echo $idResult;
			
		}
		
	}

}