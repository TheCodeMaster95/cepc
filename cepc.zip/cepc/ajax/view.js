$(document).ready(function(){
	
	/*
	$("id or class html").event(function(){
		
		val.data = [null]; //Array de datos que seran enviados, si no se desea enviar nigun dato , el valor debe ser null
		val.idResult = ''; //Nombre del id donde se mostrará el resultado
		val.nodeEvent = '', //Nombre del id o clase que dispara el evento
		val.dataType = ''; //string or json
		
		view.ajax(val.data, val.idResult, val.nodeEvent, val.dataType);
		
	});
	*/
	
	$(".che-box").click(function(){
		
		if($(this).parent('td').parent('tr').hasClass('selected')){
			
			$(this).parent('td').parent('tr').removeClass('selected');
		}
		else{
			
			$(this).parent('td').parent('tr').addClass('selected');
		}
		
	});
	
	$("#editar-perfil").submit(function(event){
		
		val.data = [$("#nombre").val(), $("#apellido").val(), $("#clave").val(), $("#id_usuario").val()];
		val.idResult = 'mensaje';
		val.nodeEvent = 'editar-perfil';
		val.dataType = 'string';
		
		view.ajax(val.data, val.idResult, val.nodeEvent, val.dataType);
		
		event.preventDefault();
	
	});
	
	$("#registrar-usuario").submit(function(event){
		
		val.data = [$("#cedula").val(), $("#nombre").val(), $("#apellido").val(), $("#tipo").val(), $("#clave").val()];
		
		val.idResult = 'mensaje';
		val.nodeEvent = 'registrar-usuario';
		val.dataType = 'string';
		
		view.ajax(val.data, val.idResult, val.nodeEvent, val.dataType);
		
		event.preventDefault();
		
	});
	
	$("#editar-usuario").submit(function(event){
		
		val.data = [$("#tipo").val(), $("#id_usuario").val()];
		val.idResult = 'mensaje';
		val.nodeEvent = 'editar-usuario';
		val.dataType = 'string';
		
		view.ajax(val.data, val.idResult, val.nodeEvent, val.dataType);
		
		event.preventDefault();
	
	});
	
	$("#eliminar-usuario").click(function(){
		
		var datos = [];
		var cantidad_datos = $(".che-box").length;
		var datos_marcados = $(".che-box:checked").length;
		
		if(cantidad_datos <= 0){
					
			alert("No hay datos para eliminar");
		
		}
				
		else if(datos_marcados <= 0){
					
			alert("Debes de marcar para eliminar");
		}
		
		else{
						
			for(var i = 0; i < datos_marcados; i++){
				
				var dato = $(".che-box:checked")[i].value;
					
				datos.push(dato);
			
			}
			
			var confirmacion = confirm("¿Desea eliminar esta informacion?");
			
			if(confirmacion == true){
				
				val.data = datos;
				val.idResult = 'mensaje';
				val.nodeEvent = 'eliminar-usuario';
				val.dataType = 'string';
				
				view.ajax(val.data, val.idResult, val.nodeEvent, val.dataType);
				
			}
			
		}
		
	});
	
	$("#registrar-curso").submit(function(event){
		
		val.data = [$("#nombre").val(), $("#duracion").val(), $("#costo").val(), $("#descripcion").val()];
		val.idResult = 'mensaje';
		val.nodeEvent = 'registrar-curso';
		val.dataType = 'string';
		
		view.ajax(val.data, val.idResult, val.nodeEvent, val.dataType);
		
		event.preventDefault();
		
	});
	
	$("#editar-curso").submit(function(event){
		
		val.data = [$("#nombre").val(), $("#duracion").val(), $("#costo").val(), $("#descripcion").val(), $("#id_curso").val()];
		
		val.idResult = 'mensaje';
		val.nodeEvent = 'editar-curso';
		val.dataType = 'string';
		
		view.ajax(val.data, val.idResult, val.nodeEvent, val.dataType);

		event.preventDefault();
		
	});
	
	$("#eliminar-curso").click(function(){
		
		var datos = [];
		var cantidad_datos = $(".che-box").length;
		var datos_marcados = $(".che-box:checked").length;
		
		if(cantidad_datos <= 0){
					
			alert("No hay datos para eliminar");
		
		}
				
		else if(datos_marcados <= 0){
					
			alert("Debes de marcar para eliminar");
		}
		
		else{
						
			for(var i = 0; i < datos_marcados; i++){
				
				var dato = $(".che-box:checked")[i].value;
					
				datos.push(dato);
			
			}
			
			var confirmacion = confirm("¿Desea eliminar esta informacion?");
			
			if(confirmacion == true){
				
				val.data = datos;
				val.idResult = 'mensaje';
				val.nodeEvent = 'eliminar-curso';
				val.dataType = 'string';
				
				view.ajax(val.data, val.idResult, val.nodeEvent, val.dataType);
				
			}
			
		}
		
	});
	
});
	