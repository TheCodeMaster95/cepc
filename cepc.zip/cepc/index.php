<?php

if(file_exists('controllers/Controller.php')){
	
	require 'views/View.php';
	require 'controllers/Controller.php';
	
	if(isset($_GET['url']) and !empty($_GET['url'])){
		
		$url = $_GET['url'];
		
		$controller = new Controller;
		$controller->route($url);
	
	}
	
	else if(isset($_GET['url']) and empty($_GET['url'])){
		
		$url = 'index'; 
		
		$controller = new Controller;
		$controller->route($url);
	}
	
	else{
		
		$url = 'welcome';
		
		$controller = new Controller;
		$controller->route($url);
		
	}
	
}
else{
	
	include('views/error.php');
	
}
