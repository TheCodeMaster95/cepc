<?php session_start(); ?>
<?php include 'models/Model.php'; ?>
<?php

if(!isset($_SESSION["id_user"])){
	
	header("location:?url=welcome");
	exit();
	
}
else{
	
	$result = $model->show_user($_SESSION["id_user"]);
	
	while($row = mysqli_fetch_array($result)){

		$nombre = $row["nombreUsuario"];
		$apellido = $row["apellidoUsuario"];
	
	}
	
	if(isset($_POST["logout"])){
	
		unset($_SESSION["id_user"]);
		unset($_SESSION["user_rol"]);
		header("location:?url=welcome");
		exit();
	
	}
	
}

