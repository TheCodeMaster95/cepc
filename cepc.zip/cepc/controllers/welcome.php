<?php session_start(); ?>
<?php include 'models/Model.php'; ?>
<?php

if(!isset($_SESSION["id_user"])){
	
	if((isset($_POST["cedula"]) and !empty($_POST["cedula"]))
	and (isset($_POST["clave"]) and !empty($_POST["clave"]))){
	
		$data = [$_POST["cedula"], $_POST["clave"]];
		
		$result =$model->select_user($data);
	
		if(mysqli_num_rows($result) > 0){
			
			while($row = mysqli_fetch_array($result)){
				
				$_SESSION["id_user"] = $row["idUsuario"];
				$_SESSION["user_rol"] = $row["tipoUsuario"];
			
			}
			
			header("location:?url=index");
			exit();
		
		
		}
	
		else{
			
			$message = '<span class="warning">Cedula o Contraseña Incorrecta</span>';
			
		}

	}

	else{
		
		$message = '<span class="warning">Debes de estar registrado</span>';
	}

	function mostrar_cursos(){
	
		$data = null;
		
		$model = new Model;
		
		$result = $model->select_courses($data);
	
		if(mysqli_num_rows($result) > 0){
			
			$num = 1;
			
			while($row = mysqli_fetch_array($result)){
			
				$data = '<tr class="resaltar">
							<td>'.$num.'</td>
							<td>'.$row["nombreCursos"].'</td>
							<td>'.$row["duracionCursos"].'</td>
							<td>'.$row["costoCursos"].'</td>
						</tr>';
						 
				echo $data;
				
				$num++;
			
			}
			
		}
		else{
			
			$data = '<tr class="resaltar">
						<td style="text-align:center" colspan="5">No hay datos para mostrar</td>
					</tr>';
			
			echo $data;
		}
		
	}
	
}

else{

	header("location:?url=index");
	exit();

}