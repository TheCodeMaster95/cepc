<?php session_start(); ?>
<?php

if(!isset($_SESSION["id_user"])){
	
	header("location:?url=welcome");
	exit();
}

