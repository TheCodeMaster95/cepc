<?php session_start(); ?>
<?php include 'models/Model.php'; ?>
<?php

if(!isset($_SESSION["id_user"])){
	
	header("location:?url=welcome");
	exit();
	
}

else{
	
	$result = $model->show_user($_SESSION["id_user"]);
	
	while($row = mysqli_fetch_array($result)){
		
		$cedula = $row["cedulaUsuario"];
		$nombre = $row["nombreUsuario"];
		$apellido = $row["apellidoUsuario"];
		$usuario = $row["tipoUsuario"];
		$password = $row["passwordUsuario"];
		
	}
	
}

