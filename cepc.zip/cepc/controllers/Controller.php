<?php
	
	class Controller{
		
		public function route($url){
			
			$view = new View;
			$view->display($url);
		
		}
		
	}