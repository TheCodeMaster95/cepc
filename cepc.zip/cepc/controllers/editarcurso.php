<?php session_start(); ?>
<?php include 'models/Model.php'; ?>
<?php

if(!isset($_SESSION["id_user"])){
	
	header("location:?url=welcome");
	exit();
}
else{
	
	if((isset($_POST["id_curso"])) and !empty($_POST["id_curso"])){
		
		$result = $model->show_course($_POST["id_curso"]);
		
		while($row = mysqli_fetch_array($result)){
			
			$nombre = $row["nombreCursos"];
			$duracion = $row["duracionCursos"];
			$costo = $row["costoCursos"];
			$descripcion = $row["descripcionCursos"];
			
		}
		
	}
	
}

