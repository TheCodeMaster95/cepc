<?php session_start(); ?>
<?php include 'models/Model.php'; ?>
<?php

if(!isset($_SESSION["id_user"])){
	
	header("location:?url=welcome");
	exit();
}

else{
	
	function mostrar_cursos(){
		
		$data = null;
		
		$model = new Model;
		
		$result = $model->select_courses($data);
		
		if(mysqli_num_rows($result) > 0){
			
			$num = 1;
			
			while($row = mysqli_fetch_array($result)){
				
				$data = '<tr class="resaltar">
							<td style="text-align:center">'.$num.'</td>
							<td>'.$row["nombreCursos"].'</td>
							<td>'.$row["duracionCursos"].'</td>
							<td>'.$row["costoCursos"].'</td>
							<td style="text-align:center">
								<input class="che-box" type="checkbox" value="'.$row["idCursos"].'"/>
							</td>
							<td>
								<form action="?url=editarcurso" method="POST">
									<input type="hidden" name="id_curso" value="'.$row["idCursos"].'"/>
									<input type="submit" class="btn" value="Editar"/>
								</form>
							</td>
						 </tr>';
						 
				echo $data;
				
				$num++;
				
			}
			
		}
		else{
			
			$data = '<tr class="resaltar">
						<td style="text-align:center" colspan="6">No hay datos para mostrar</td>
					</tr>';
					
			
			echo $data;
			
		}
		
	}
	
}
