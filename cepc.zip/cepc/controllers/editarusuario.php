<?php session_start(); ?>
<?php include 'models/Model.php'; ?>
<?php

if(!isset($_SESSION["id_user"])){
	
	header("location:?url=welcome");
	exit();
}
else{
	
	if((isset($_POST["id_usuario"])) and !empty($_POST["id_usuario"])){
	
		$result = $model->show_user($_POST["id_usuario"]);
		
		while($row = mysqli_fetch_array($result)){
			
			$GLOBALS["id"] = $row["idUsuario"];
			$cedula = $row["cedulaUsuario"];
			$nombre = $row["nombreUsuario"];
			$apellido = $row["apellidoUsuario"];
			$GLOBALS["tipo"] = $row["tipoUsuario"];
			$password = $row["passwordUsuario"];
			
		}
			
		function mostrar_rol(){
		
			if($GLOBALS["id"] == $_SESSION["id_user"]){
				
				$data = '<option value="'.$GLOBALS["tipo"].'">'.$GLOBALS["tipo"].'</option>';
				
				echo $data;
							
			}
		
			else if(($GLOBALS["id"] != $_SESSION["id_user"]) and ($GLOBALS["tipo"] == 'ADMINISTRADOR')){
				
				$data = '<option value="'.$GLOBALS["tipo"].'">'.$GLOBALS["tipo"].'</option>';
				$data.= '<option value="INVITADO">INVITADO</option>';
				
				echo $data;
			}
		
			else if(($GLOBALS["id"] != $_SESSION["id_user"]) and ($GLOBALS["tipo"] == 'INVITADO')){
					
				$data = '<option value="'.$GLOBALS["tipo"].'">'.$GLOBALS["tipo"].'</option>';
				$data.= '<option value="ADMINISTRADOR">ADMINISTRADOR</option>';
				
				echo $data;
			}
		
		}	
		
	}
	
}

