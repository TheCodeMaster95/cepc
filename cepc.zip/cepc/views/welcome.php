<?php include 'controllers/welcome.php' ?>
<!DOCTYPE html>
<!--<html xmlns="http://www.w3.org/1999/xhtml">-->
	<html>
		<head>
			<title>CEPC C.A</title>
			<meta charset="UTF-8">
			<meta name="autor" content="Aaron Carreño">
			<meta name="description" content="Centro de estudio para la capacitacion en el area laboral">
			<meta name="keywords" content="Petroleo, Comercio, Trabajo, El Tigre, Anzoátegui">
		<!--<meta http-equiv="refresh" content="5;URL=''">-->
			<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
			<link rel="shortcut icon" type="image/x-icon" href="resources/img/logotipo-1.PNG">
			<link rel="stylesheet" href="resources/css/awesone.css">
			<link rel="stylesheet" href="resources/css/slider.css">
			<link rel="stylesheet" href="resources/css/styles.css">
			<link rel="stylesheet" href="resources/css/font-awesome.min.css">
			<script src="resources/js/jquery-des-3.2.1.min.js"></script>
			<script src="resources/js/scripts.js"></script>
		</head>
		<body>
			<div id="contenedor">
<?php include 'templates/header.php'; ?>
				<nav class="men-2">
					<ul>
						<a href="?url=welcome" title="Inicio"><li><i class="fa fa-home"></i><br>Inicio</li></a>
						<a href="#nosotros" title="Nosotros"><li><i class="fa fa-group"></i><br>Nosotros</li></a>
						<a href="#cursos" title="Cursos"><li><i class="fa fa-book"></i><br>Cursos</li></a>
						<a href="#contacto" title="Contacto"><li><i class="fa fa-envelope"></i><br>Contacto</li></a>
					</ul>
				</nav>
				<section id="pre-ini-1">
					<div class="fil">
						<div class="col-2">
							<div class="contenedor-imagenes">
								<figure>
									<img src="resources/img/img-1.jpeg"/>
								</figure>
								<figure>
									<img src="resources/img/img-2.jpeg"/>
								</figure>
								<figure>
									<img src="resources/img/img-3.jpeg"/>
								</figure>
							</div>
						</div>
						<div class="col-1">
							<form class="formulario" method="POST" action="?url=welcome">
								<br>
								<h5>Iniciar Sesión</h5>
								<ul>
									<li>
										<input type="text" class="campo-numeros" maxlength=9 placeholder="Cedula" name="cedula" required/>
									</li>
									<li>
										<input type="password"  placeholder="Contraseña" name="clave" required/>
									</li>
									<li>
										<br/>
											<input class="btn" type="submit" value="Ingresar"/>
										<br/>
									</li>
								</ul>
								<br/>
									<div id="mensaje">
										<?php echo $message; ?>
									</div>
								<br/>
							</form>
						</div>
					</div>
				</section>
				<br>
				<br>
				<br>
				<section id="pre-ini-2">
					<div class="fil">
						<div class="col-1">
							<article>
								<header>
									<h4 class="tit-enc" id="nosotros">CEPC CA</h4>
								</header>
								<br/>
								<br/>
								<p>El Centro Educativo Petrolero y Comercial (CEPC), es una institución de aprendizaje laboral ubicada en El Tigre Municipio Simón Rodríguez Estado Anzoátegui Venezuela. Con mas de 10 años en el área educativa y contando con profesores altamente preparados, nos encargamos de impartir cursos certificados con la finalidad de capacitar, a todo aquel personal bien sea particular, estudiantil, obrero o empresarial con el deseo de alcanzar un nível de profesionalismo óptimo. Con la bendición de Dios para iluminar a la sociedad y hacer del ser humano un hombre crítico de reflexión, del buen vivir, productivo y útil a la patria, nuestra misión es lograr bajo tutela del Estado Venezolano y en colaboración con los patrones y trabajadores de los sectores productivos de bienes y servicios, una eficiente formación y capacitación continua de la fuerza laboral complementando la educación recibida en el sistema formal.</p>
								<br/>
								<br/>
								<p style="text-align:center">
									<cite>"Moral y luces son los polos de una República, moral y luces son nuestras primeras necesidades"</cite><br>
									<cite><strong style="text-decoration:none">Simón Bolívar</strong></cite>
								</p>
								<br/>
								<br/>
							</article>
						</div>
					</div>
				</section>
				<section id="pre-ini-3">
					<div class="fil">
						<div class="col-3">
							<article>
								<header>
									<h4>Registro</h4>
								</header>
								<p style="text-align:center">Dirígite a la institución, pregunta por el curso de tu interés y realiza el <b>registro</b> de tus datos personales</p>
							</article>
							<figure>
								<img src="resources/img/ico-1.png"/>
							</figure>
						</div>
						<div class="col-3">
							<article>
								<header><h4>Capacitación</h4></header>
								<p style="text-align:center">Asiste de acuerdo a tu horario de estudio y cumple conlo exigido durante tu proceso de <b>capacitación</b></p>
							</article>
							<figure>
								<img src="resources/img/ico-2.png"/>
							</figure>
						</div>
						<div class="col-3">
							<article>
								<header><h4>Certificación</h4></header>
								<p style="text-align:center">Finaliza y aprueba el curso para que tu <b>certificación</b> sea gestionada y luego entregada</p>
							</article>
							<figure>
								<img src="resources/img/ico-3.png"/>
							</figure>
						</div>
					</div>
				</section>
				<br>
				<br>
				<br>
				<section id="pre-cur">
					<div class="fil">
						<div class="col-2">
						<h4 class="tit-enc" id="cursos">CURSOS</h4>
							<div class="over">
								<table class="tab-1">
									<thead>
										<tr>
											<th>Nº</th>
											<th>Nombre</th>
											<th>Duración</th>
											<th>Costo</th>
										</tr>
									</thead>
									<tbody>
									<?php mostrar_cursos() ?>
									</tbody>
								</table>
							</div>
							<br>
							<span>Para mayor información, comunicarse con los números que estan al final de la página</span>
						</div>
					</div>
				</section>
				<br>
				<br>
				<br>
<?php include 'templates/footer.php'; ?>
			</div>
		</body>
	</html>