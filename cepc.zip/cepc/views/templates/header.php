<header id="encabezado-principal">
	<div class="fil">
		<div class="col-4">
			<figure>
				<img src="resources/img/logotipo-1.PNG"/>
			</figure>
		</div>
		<div class="col-6">
			<h2>
				República Bolivariana de Venezuela
				<br/>
				Centro Educativo Petrolero y Comercial
				<br/>
				El Tigre Estado Anzoátegui
				<br/>
				R.I.F: j-31497525-0
			</h2>
		</div>
		<div class="col-4">
			<figure>
				<img src="resources/img/logotipo-2.PNG"/>
			</figure>
		</div>
	</div>
</header>