<footer id="contacto">
	<div class="fil">
		<div class="col-5" id="pie">
			<small>Centro Educativo en el Área Petrolera y Comercial C.A.</small>
			<br/>
			<small>Calle Soublete, Sector Pueblo Nuevo Norte, El Tigre / Anzoátegui </small>
			<br/>
			<small>Registro del Ministerio de Educación 0245-04-06</small>
			<br/>
			<small>Registro INCE 714911</small>
			<br/>
			<small>Fecha del Registro Mercantil <time>2006/01/24</time></small>
			<br/>
			<small>Zona Postal 6050</small>
			<br/>
			<small>0283-2358569 / 0412-0817694</small>
		</div>
		<br>
		<br>
		<br>
		<div class="fil" style="text-align:right">
			<small>Todos los Derechos Reservados &copy 2020</small>
		</div>
	</div>
</footer>