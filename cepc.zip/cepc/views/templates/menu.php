<nav class="men-1">
	<ul>
		<a href="?url=index"><li class="ite-men">Inicio&nbsp;<i class="fa fa-home"></i></li></a>
		<a href="?url=cursos"><li class="ite-men">Cursos&nbsp;<i class="fa fa-book"></i></li></a>
<?php
	
	if($_SESSION["user_rol"] == 'ADMINISTRADOR'){
?>
		<a href="?url=usuarios"><li class="ite-men">Usuarios&nbsp;<i class="fa fa-user"></i></li></a>
<?php

	}
?>
		<a href="#" id="logout"><li class="ite-men">Salir&nbsp;<i class="fa fa-sign-out"></i></li></a>
	</ul>
</nav>