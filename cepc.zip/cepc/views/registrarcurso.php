<?php include 'controllers/registrarcurso.php'; ?>
<!DOCTYPE html>
	<html xmlns="http://www.w3.org/1999/xhtml">
		<head>
			<title>CEPC C.A</title>
			<meta charset="UTF-8">
			<meta name="autor" content="Aaron Carreño">
			<meta name="description" content="Centro de estudio para la capacitacion en el area laboral">
			<meta name="keywords" content="Petroleo, Comercio, Trabajo, El Tigre, Anzoátegui">
		<!--<meta http-equiv="refresh" content="5;URL=''">-->
			<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
			<link rel="shortcut icon" type="image/x-icon" href="resources/img/logotipo-1.PNG">
			<link rel="stylesheet" href="resources/css/awesone.css">
			<link rel="stylesheet" href="resources/css/slider.css">
			<link rel="stylesheet" href="resources/css/styles.css">
			<link rel="stylesheet" href="resources/css/font-awesome.min.css">
			<script src="resources/js/jquery-des-3.2.1.min.js"></script>
			<script src="resources/js/ajax-lite.js"></script>
			<script src="resources/js/scripts.js"></script>
			<script src="ajax/view.js"></script>
		</head>
		<body>
			<div id="contenedor">
<?php include 'templates/header.php'; ?>
				<section class="panel">
					<div class="fil">
						<div class="col-1">
<?php include 'templates/menu.php'; ?>
						</div>
						<div class="col-2">
							<h4 class="tit-enc">Registrar Curso</h4>
							<form style="background:0;border:0;min-height:0;padding: 0.5em 0" class="formulario" id="registrar-curso">
								<table class="tab-2">
									<tbody>
										<tr>
											<td class="atr-1">Nombre</td>
											<td class="atr-2"><input type="text" id="nombre" class="campo-letras" autofocus required/></td>			
										</tr>
										<tr>
											<td class="atr-1">Duración</td>
											<td class="atr-2"><input type="text" id="duracion" class="campo" required/></td>
										</tr>
										<tr>
											<td class="atr-1">Precio</td>
											<td class="atr-2"><input disabled/></td>
										</tr>
										<tr>
											<td class="atr-1">Costo</td>
											<td class="atr-2"><input type="text" class="campo" id="costo" required/></td>
										</tr>
									</tbody>
								</table>
								<textarea style="color:#000" id="descripcion" class="campo" placeholder="Descripcion..."></textarea>
								<br>
								<br>
								<ul style="border:0">
									<li style="text-align:left">
										<a style="text-decoration:none" href="#">
											<input style="width:45%" class="btn" type="submit" value="Aceptar"/>
										</a>
										<a style="text-decoration:none" href="?url=cursos">
											<input style="width:45%" class="btn" type="button" value="Volver"/>
										</a>
									</li>
									<li style="text-aling:right" id="mensaje"></li>
								</ul>
							</form>
						</div>
					</div>
				</section>
				<br>
				<br>
				<br>
<?php include 'templates/footer.php'; ?>
			</div>
			<form style="display: none" action="?url=index" method="POST" id="sign-out">
				<input type="hidden" name="logout">
			</form>
		</body>
	</html>
