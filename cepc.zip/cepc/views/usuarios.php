<?php include 'controllers/usuarios.php'; ?>
<!DOCTYPE html>
	<html xmlns="http://www.w3.org/1999/xhtml">
		<head>
			<title>CEPC C.A</title>
			<meta charset="UTF-8">
			<meta name="autor" content="Aaron Carreño">
			<meta name="description" content="Centro de estudio para la capacitacion en el area laboral">
			<meta name="keywords" content="Petroleo, Comercio, Trabajo, El Tigre, Anzoátegui">
		<!--<meta http-equiv="refresh" content="5;URL=''">-->
			<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
			<link rel="shortcut icon" type="image/x-icon" href="resources/img/logotipo-1.PNG">
			<link rel="stylesheet" href="resources/css/awesone.css">
			<link rel="stylesheet" href="resources/css/slider.css">
			<link rel="stylesheet" href="resources/css/styles.css">
			<link rel="stylesheet" href="resources/css/font-awesome.min.css">
			<script src="resources/js/jquery-des-3.2.1.min.js"></script>
			<script src="resources/js/ajax-lite.js"></script>
			<script src="resources/js/scripts.js"></script>
			<script src="ajax/view.js"></script>
		</head>
		<body>
			<div id="contenedor">
<?php include 'templates/header.php'; ?>
				<section class="panel">
					<div class="fil">
						<div class="col-1">
<?php include 'templates/menu.php'; ?>
						</div>
						<div class="col-2">
							<h4 class="tit-enc">
								<ul style="margin:0 auto; padding:0">
									<li style="display:inline-block;width:48%;text-align:left">Usuarios</li>
									<li style="display:inline-block;width:48%;text-align:right"><input type="text" class="campo" data-id="fil-dat" placeholder="Buscar" autofocus="on" autocomplete="off"/></li>
								</ul>
							</h4>
							<div class="over">
								<table class="tab-1">
									<thead>
										<tr>
											<th>Nº</th>
											<th>Cedula</th>
											<th>Nombre</th>
											<th>Rol</th>
											<th>Marcar</th>
											<th>Opción</th>
										</tr>
									</thead>
									<tbody>
									<?php mostrar_usuarios(); ?>
									</tbody>
								</table>
							</div>
							<br>
							<ul style="border:0">
								<li style="text-align:left">
									<a style="text-decoration:none" href="?url=registrarusuario">
										<input style="width:45%" class="btn" type="button" value="Registrar"/>
									</a>
									<a style="text-decoration:none" href="#" onclick="event.preventDefault();">
										<input style="width:45%" class="btn" type="button" id="eliminar-usuario" value="Eliminar"/>
									</a>
								</li>
								<li style="text-align:right" id="mensaje"></li>
							</ul>
						</div>
					</div>
				</section>
				<br>
				<br>
				<br>
<?php include 'templates/footer.php'; ?>
			</div>
			<form style="display: none" action="?url=index" method="POST" id="sign-out">
				<input type="hidden" name="logout">
			</form>
		</body>
	</html>
