<?php
	
	class View{
		
		public function display($url){
			
			if(file_exists('views/'.$url.'.php')){
				
				include('views/'.$url.'.php');
			
			}
			else{
				
				include('views/404.php');
				
			}
		
		}
		
	}